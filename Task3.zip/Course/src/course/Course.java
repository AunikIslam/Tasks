/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package course;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class Course {
    int i=0;
    int j=0;
    String choice;
    String [][] details;
    String [] input2 = new String[10];
    String [] input3 = new String[10];
    String [] input4 = new String[10];
    String[][] coursedetails = new String[10][20];
    Course(String c){
        choice = c;
        //details = arr;
        
    }
    
    Course(){
    
    }
    void printcourse(){
        
        

        
        System.out.println("A. Create Routine");
        System.out.println("B. Show Routine");
        System.out.println("C. List Courses with Teachers Name");
    
    }
    
    void print(){
        coursedetails[0][0] = "English Grammar";
        coursedetails[0][1] = "John Smith";
        coursedetails[1][0] = "Mathematics";
        coursedetails[1][1] = "Lara Gilbert";
        coursedetails[2][0] = "Physics";
        coursedetails[2][1] = "Johanna Kabir"; 
        coursedetails[3][0] = "Chemistry"; 
        coursedetails[3][1] = "Danniel Robertson";
        coursedetails[4][0] = "Biology";
        coursedetails[4][1] =  "Larry Coope";
        if(choice.equals("C")){
           for (i = 0; i<5;i++){
               for(j=0;j<1;j++){
                   System.out.print(coursedetails[i][j] + "," + coursedetails[i][j+1]);
                   
               }
               System.out.println();
           }
        }
        if(choice.equals("A")){
            for(i=0;i<5;i++){
            System.out.println(i+1+" . "+ coursedetails[i][0]);
            }
                
        Scanner myObj2 = new Scanner(System.in);
        //String input2 = myObj2.nextLine(); 
        //int number2 = Integer.parseInt(input2);
        
        Scanner myObj3 = new Scanner(System.in);
        //String input3 = myObj3.nextLine(); 
        //int number3 = Integer.parseInt(input3);
        
        
        
        Scanner myObj4 = new Scanner(System.in);
        
        for (int k = 0; k<4;k++){
            input2[k] = myObj2.nextLine();
            input3[k] = myObj3.nextLine();
            input4[k] = myObj4.nextLine();
        }
        //String input4 = myObj4.nextLine();
        //int number4 = Integer.parseInt(input4);
        
        printcourse();

        Scanner myObj = new Scanner(System.in);
        String input1 = myObj.nextLine(); 

        if(input1.equals("B")){
            
            for(int k=0;k<4;k++){
                System.out.println(input2[k] + " " + input3[k] + " "+ coursedetails[Integer.parseInt(input4[k])][0]);
            }
            
        }
        

        }
    }
    
    public static void main(String[] args) {
        
        Course course2 = new Course();
        course2.printcourse();
        Scanner myObj = new Scanner(System.in);
        String userinput = myObj.nextLine(); 
        
        Course  course = new Course(userinput);
        
        course.print();
        
    }
    
}
